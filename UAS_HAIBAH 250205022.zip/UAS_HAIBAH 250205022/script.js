
// FUNGSI UNTUK MEMBUKA MENU
function bukaHalaman(namaHalaman) {

    var halaman = document.getElementsByClassName("halaman");

    // Menyembunyikan semua halaman
    for (var i = 0; i < halaman.length; i++) {
        halaman[i].classList.remove("aktif");
    }

    // Menampilkan halaman yang dipilih
    document.getElementById(namaHalaman).classList.add("aktif");

    window.scrollTo(0, 0);
}


// VALIDASI FORMULIR KONSULTASI
document.getElementById("formKonsultasi").addEventListener("submit", function(event) {

    event.preventDefault();

    var nama = document.getElementById("nama").value;
    var email = document.getElementById("email").value;
    var telepon = document.getElementById("telepon").value;
    var pesan = document.getElementById("pesan").value;

    // Memeriksa apakah semua data sudah diisi
    if (nama == "" || email == "" || telepon == "" || pesan == "") {

        alert("Semua kolom harus diisi!");

    } else if (!email.includes("@") || !email.includes(".")) {

        alert("Masukkan alamat email yang benar!");

    } else if (!/^[0-9]{10,15}$/.test(telepon)) {

        alert("Nomor telepon harus terdiri dari 10-15 angka!");

    } else {

        document.getElementById("hasil").innerHTML =
        "Terima kasih, " + nama + ". Pesan Anda berhasil divalidasi!";

        alert("Formulir berhasil diisi!");

        // Mengosongkan formulir
        document.getElementById("formKonsultasi").reset();
    }

});
